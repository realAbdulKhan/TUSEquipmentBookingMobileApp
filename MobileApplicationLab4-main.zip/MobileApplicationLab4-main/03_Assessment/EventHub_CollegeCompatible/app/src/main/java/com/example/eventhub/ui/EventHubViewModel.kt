package com.example.eventhub.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventhub.data.EventRepository
import com.example.eventhub.data.local.EventHubDatabase
import com.example.eventhub.model.Category
import com.example.eventhub.model.Event
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth

data class EventHubUiState(
    val events: List<Event> = emptyList(),
    val categories: List<Category> = emptyList(),
    val isLoading: Boolean = true,
    val loadError: String? = null,
    val actionMessage: String? = null,
    val isAdding: Boolean = false
)

class EventHubViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = EventRepository(
        EventHubDatabase.getInstance(application)
    )
    private val mutableUiState = MutableStateFlow(EventHubUiState())
    val uiState = mutableUiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                repository.seedIfEmpty()
                combine(repository.events, repository.categories) { events, categories ->
                    events to categories
                }.collect { (events, categories) ->
                    mutableUiState.update {
                        it.copy(events = events, categories = categories,
                            isLoading = false, loadError = null)
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                mutableUiState.update {
                    it.copy(isLoading = false,
                        loadError = error.message ?: "Unable to load events")
                }
            }
        }
    }

    private fun requireLogin() {
        check(FirebaseAuth.getInstance().currentUser != null) {
            "Please log in to manage events"
        }
    }

    fun addTestEvent() {
        val current = mutableUiState.value
        val categoryId = current.categories.firstOrNull()?.id ?: return
        if (current.isLoading || current.isAdding || current.loadError != null) return
        mutableUiState.update { it.copy(isAdding = true, actionMessage = null) }
        viewModelScope.launch {
            try {
                requireLogin()
                val id = repository.addEvent(categoryId)
                mutableUiState.update {
                    it.copy(actionMessage = "Saved event with ID $id")
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                mutableUiState.update {
                    it.copy(actionMessage = error.message ?: "Unable to save event")
                }
            } finally {
                mutableUiState.update { it.copy(isAdding = false) }
            }
        }
    }

    fun saveEvent(event: Event) {
        val current = mutableUiState.value
        if (current.isLoading || current.isAdding || current.loadError != null) return
        mutableUiState.update { it.copy(isAdding = true, actionMessage = null) }
        viewModelScope.launch {
            try {
                requireLogin()
                val id = repository.saveEvent(event)
                mutableUiState.update { it.copy(actionMessage = "Saved event with ID $id") }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                mutableUiState.update {
                    it.copy(actionMessage = error.message ?: "Unable to save event")
                }
            } finally {
                mutableUiState.update { it.copy(isAdding = false) }
            }
        }
    }

    fun updateEvent(event: Event) {
        val current = mutableUiState.value
        if (current.isLoading || current.isAdding || current.loadError != null) return
        mutableUiState.update { it.copy(isAdding = true, actionMessage = null) }
        viewModelScope.launch {
            try {
                requireLogin()
                repository.updateEvent(event)
                mutableUiState.update { it.copy(actionMessage = "Updated event ${event.title}") }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                mutableUiState.update {
                    it.copy(actionMessage = error.message ?: "Unable to update event")
                }
            } finally {
                mutableUiState.update { it.copy(isAdding = false) }
            }
        }
    }

    fun deleteEvent(eventId: Int) {
        val current = mutableUiState.value
        if (current.isLoading || current.isAdding || current.loadError != null) return
        mutableUiState.update { it.copy(isAdding = true, actionMessage = null) }
        viewModelScope.launch {
            try {
                requireLogin()
                repository.deleteEvent(eventId)
                mutableUiState.update { it.copy(actionMessage = "Event deleted") }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                mutableUiState.update {
                    it.copy(actionMessage = error.message ?: "Unable to delete event")
                }
            } finally {
                mutableUiState.update { it.copy(isAdding = false) }
            }
        }
    }
}
